package commands;

import static main.run.area;
import static main.run.currentLoc;

public class cLook implements commandBase{
    public void run(String[] command) {
        area.addText(currentLoc.getInfo());
    }
}
