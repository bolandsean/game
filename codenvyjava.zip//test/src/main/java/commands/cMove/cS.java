package commands.cMove;

import commands.commandBase;

import static main.run.area;
import static main.run.currentLoc;

public class cS implements commandBase {
    public void run(String[] command) {
        if(currentLoc.getDirs().contains("s")){
            currentLoc.moveW();
        }else{
            area.addText("Cannot go south!");
        }
    }
}
