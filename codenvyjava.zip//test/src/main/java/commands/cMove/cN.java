package commands.cMove;

import commands.commandBase;

import static main.run.area;
import static main.run.currentLoc;

public class cN implements commandBase {
    public void run(String[] command) {
        if(currentLoc.getDirs().contains("n")){
            currentLoc.moveW();
        }else{
            area.addText("Cannot go north!");
        }
    }
}
