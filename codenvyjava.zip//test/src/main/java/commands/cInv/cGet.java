package commands.cInv;

import commands.commandBase;

import static main.run.area;
import static main.run.currentLoc;

public class cGet implements commandBase {
    public void run(String[] command) {
        if(currentLoc.getItems().contains(command[1])){
            currentLoc.modifyItems(command[1], false);
            cInv.modifyItems(command[1], true);
            area.addText("You grab the "+command[1]+".");
        }else{
            area.addText("You cannot grab that!");
        }
    }
}
