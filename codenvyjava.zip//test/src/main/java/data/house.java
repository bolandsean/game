package data;


import java.util.ArrayList;

import static main.run.area;
import static main.run.currentLoc;

public class house implements loc{
    private static ArrayList<String> dirs = new ArrayList<>();
    private static ArrayList<String> items = new ArrayList<>();
    private static boolean firstRun = true;
    public static void run(){
        if(firstRun){
            firstRun=false;
            currentLoc = new house();
            area.addText("You walk outside the barn, and find yourself in front of a luxurious house. There is also a path through a field.\nThe entrance to the house is to the north, the barn is to the south, and there is a path through the empty field to the east.",true);
            dirs.add("s");
            dirs.add("n");
            dirs.add("e");
            items.add("item2");
            items.add("box");
            if(items.size()>0){
                area.addText("You see some items on the ground:");
                for(int i=0;i<items.size();i++){
                    area.addText("    * "+items.get(i));
                }
            }
        }else{
            currentLoc = new house();
            area.addText("You are outside of a very fancy house and a field to the side. \nThe entrance to the house is to the north, the barn is to the south, and there is a path through the empty field to the east.");
            if(items.size()>0) {
                area.addText("You see some items on the ground:");
                for (int i = 0; i < items.size(); i++) {
                    area.addText("    * " + items.get(i));
                }
            }
        }
    }
    public String getInfo(){
        String out = "You are outside of a very fancy house and a field to the side. \nThe entrance to the house is to the north, the barn is to the south, and there is a path through the empty field to the east.";
        if(items.size()>0){
            out+="\nYou see some items on the ground:";
            for(int i=0;i<items.size();i++){
                out+=("\n    * "+items.get(i));
            }
        }
        return out;
    }
    public ArrayList<String> getDirs() {
        return dirs;
    }
    public ArrayList<String> getItems() {
        return items;
    }
    public void modifyItems(String item, boolean add){
        if(add){
            items.add(item);
        }else{
            items.remove(item);
        }
    }
    public void moveN(){
    }
    public void moveE(){
    }
    public void moveS(){
        barn.run();
    }
    public void moveW(){
    }
}
