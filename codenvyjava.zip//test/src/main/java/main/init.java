package main;

import commands.*;
import commands.cInv.*;
import commands.cMove.*;
import objects.command;

public class init extends run {
    public static void preInit(){
        command cHelp = new command("help", new cHelp());
        command cStart = new command("start", new cStart());
        command cExit = new command("exit", new cExit());
    }
    public static void postInit(){
        command cN = new command("n", new cN());
        command cE = new command("e", new cE());
        command cS = new command("s", new cS());
        command cW = new command("w", new cW());
        command cGet = new command("get", new cGet());
        command cLook = new command("look", new cLook());
        command cDrop = new command("drop", new cDrop());
        command cI = new command("i", new cInv());
    }
}
