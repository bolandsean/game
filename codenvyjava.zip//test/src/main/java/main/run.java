package main;

import data.loc;
import objects.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class run {
    public static String input = "";
    public static textArea area;
    public static boolean started = false;
    public static loc currentLoc;
    public static void main(){
        init.preInit();
        JLabel label = new JLabel("Enter Text:");
        JTextField field = new JTextField();
        JButton button = new JButton("Submit");
        area = new textArea(20,70, false);
        area.setText("Welcome to Adventure! To start type \"start\" and type \"help\" for a list of commands!\n");
        JPanel top = new JPanel();
        JPanel bottom = new JPanel();
        JScrollPane scroll = new JScrollPane(area.area);
        scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        field.setMinimumSize(new Dimension(50,25));
        field.setPreferredSize(new Dimension(200,25));
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                input = field.getText().toLowerCase();
                if(!input.equals("")) {
                    area.addText(input, false);
                    field.setText("");
                    String[] words = input.split(" ");
                    command.process(words);
                }
            }
        });
        frame window = new frame("Adventure", top, 1000, 600, false, true, true);
        window.addPanel(top);
        window.addPanel(bottom);
        window.add(label, bottom);
        window.add(field, bottom);
        window.add(button, bottom);
        window.setDefaultButton(button);
        window.add(scroll, top);
        Insets insets = window.getInsets();
        window.setDims(top,insets.left, insets.top-10, window.getWidth(), 400);
        window.setDims(bottom, insets.left, 400 + insets.top, window.getWidth(), 50);
    }
}
