package objects;

import java.io.*;

public class Save {
    File save;
    public Save(String name){
        save = new File(name+".txt");
        newS();
    }
    public Save(File file){
        save = file;
        continueS();
    }
    public void newS(){
        
    }
    public void continueS(){
        
    }
}
