package data;

import java.util.ArrayList;

public interface loc {
    static void firstRun(){}
    static void run(){}
    String getInfo();
    ArrayList<String> getDirs();
    ArrayList<String> getItems();
    void modifyItems(String item, boolean add);
    void moveN();
    void moveE();
    void moveS();
    void moveW();
}

