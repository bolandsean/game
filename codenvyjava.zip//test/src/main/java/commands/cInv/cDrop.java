package commands.cInv;

import commands.commandBase;

import static main.run.area;
import static main.run.currentLoc;

public class cDrop implements commandBase {
    public void run(String[] command) {
        if(cInv.getItems().contains(command[1])){
            currentLoc.modifyItems(command[1], true);
            cInv.modifyItems(command[1], false);
            area.addText("You drop the "+command[1]+".");
        }else{
            area.addText("You cannot drop that!");
        }
    }
}
