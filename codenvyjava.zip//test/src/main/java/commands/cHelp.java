package commands;

import static main.run.area;

public class cHelp implements commandBase{
    public void run(String[] command){
        area.addText("You can type \"help\" at any time to view this message again. To grab an item and put it in your inventory,\ntype \"get\" and then the name of the " +
                "item you want to grab. You can drop an item by typing \"drop\" and then the name of the item you want to drop.\n" +
                "To move, type the first letter of the direction you want to go.\n" +
                "To look in your inventory, type \"i\", and type\"look\" to repeat the information about the current location. You can\n" +
                "type \"exit\" at anytime to exit the application. Type \"start\" to begin the adventure",true);
    }
}

