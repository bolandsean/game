package commands;

import static main.run.area;
import static main.run.started;
import data.barn;
import main.init;

public class cStart implements commandBase{
    public void run(String[] command) {
        if(!started){
            started = true;
            barn.run();
            init.postInit();
        }else{
            area.addText("Game already started!", true);
        }
    }
}

