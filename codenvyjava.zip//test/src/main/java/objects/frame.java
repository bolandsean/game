package objects;

import javax.swing.*;
import java.awt.*;

public class frame {
    private JFrame frame;
    private JPanel panel;
    public frame(String title, JPanel defaultPanel, int width, int height, boolean sizable, boolean exitOnClose, boolean visible){
        frame = new JFrame(title);
        panel = defaultPanel;
        frame.getContentPane().add(panel);
        if(exitOnClose){
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        }else{
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        }
        frame.setMinimumSize(new Dimension(100,100));
        frame.setSize(new Dimension(width,height));
        frame.setResizable(sizable);
        frame.setLocationRelativeTo(null);
        frame.setLayout(null);
        frame.setVisible(visible);
    }
    public void add(Component component){
        panel.add(component);
    }
    public void add(Component component, JPanel panel){
        panel.add(component);
    }
    public void addPanel(JPanel panel){
        frame.getContentPane().add(panel);
    }
    public void setDefaultButton(JButton button){
        JRootPane rootPane = SwingUtilities.getRootPane(button);
        rootPane.setDefaultButton(button);
    }
    public void setDims(Component component, int x, int y, int w, int h){
        component.setBounds(x,y,w,h);
    }
    public int getWidth(){
        return frame.getWidth();
    }
    public int getHeight(){
        return frame.getHeight();
    }
    public Insets getInsets(){
        return frame.getInsets();
    }
}
