package commands;

public class cExit implements commandBase{
    public void run(String[] command){
        System.exit(0);
    }
}
