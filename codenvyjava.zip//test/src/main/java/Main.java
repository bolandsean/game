//import java.util.*;
//import java.io.*;
import main.run;

public class Main {
    public static void main(String[] args){
        run.main();
    }
   /* public static void main(String[] args){
        if(args.length==0) System.out.println("An argument is required for the name of your save file.");
        else{
            try{
                Scanner file = new Scanner(new File(args[0]+".txt"));
                file.close();
                System.out.println("Save file found. Continuing from the save.");
                Save save = new Save(new File(args[0]+".txt"));
            }
            catch(FileNotFoundException fnfe){
                System.out.println("Unable to find "+args[0]+".txt, creating a new save");
                Save save = new Save(args[0]);
            }
            catch(NoSuchElementException nsee){
                System.out.println("Attempt to read past the end of the file");
            }
            catch(IllegalStateException ise){
                System.out.println("Attempt to read after the file is closed");
            }
        }
    }*/
}