package data;

import java.util.ArrayList;
import static main.run.area;
import static main.run.currentLoc;

public class barn implements loc{
    private static ArrayList<String> dirs = new ArrayList<>();
    private static ArrayList<String> items = new ArrayList<>();
    private static boolean firstRun = true;
    public static void run(){
        if(firstRun){
            firstRun=false;
            currentLoc = new barn();
            area.addText("You wake up and find yourself in an old abandoned barn. You don't know how you got there, but you see an exit to the north.",true);
            dirs.add("n");
            items.add("item1");
            items.add("hay");
            if(items.size()>0){
                area.addText("You see some items on the ground:");
                for(int i=0;i<items.size();i++){
                    area.addText("    * "+items.get(i));
                }
            }
        }else{
            currentLoc = new barn();
            area.addText("You are in an old abandoned barn. The exit is to the north.");
            if(items.size()>0) {
                area.addText("You see some items on the ground:");
                for (int i = 0; i < items.size(); i++) {
                    area.addText("    * " + items.get(i));
                }
            }
        }
    }
    public String getInfo(){
        String out = "You are in an old abandoned barn. The exit is to the north.";
        if(items.size()>0){
            out+="\nYou see some items on the ground:";
            for(int i=0;i<items.size();i++){
                out+=("\n    * "+items.get(i));
            }
        }
        return out;
    }
    public ArrayList<String> getDirs() {
        return dirs;
    }
    public ArrayList<String> getItems() {
        return items;
    }
    public void modifyItems(String item, boolean add){
        if(add){
            items.add(item);
        }else{
            items.remove(item);
        }
    }
    public void moveN(){
        house.run();
    }
    public void moveE(){
    }
    public void moveS(){
    }
    public void moveW(){
    }
}

