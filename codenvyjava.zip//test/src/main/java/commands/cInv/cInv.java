package commands.cInv;

import commands.commandBase;
import java.util.ArrayList;
import static main.run.area;

public class cInv implements commandBase {
    private static ArrayList<String> inv = new ArrayList<>();
    public void run(String[] command) {
        area.addText("You look in your bag and find:");
        for(int i=0;i<inv.size();i++){
            area.addText("    * "+inv.get(i));
        }
    }
    public static ArrayList<String> getItems(){
        return inv;
    }
    public static void modifyItems(String item, boolean add){
        if(add){
            inv.add(item);
        }else{
            inv.remove(item);
        }
    }
}
