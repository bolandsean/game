package objects;

import commands.commandBase;
import java.util.ArrayList;
import static main.run.area;

public class command {
    private static ArrayList<String> names = new ArrayList<>();
    private static ArrayList<commandBase> classes = new ArrayList<>();
    public command(String name, commandBase object){
        names.add(name);
        classes.add(object);
    }
    public static boolean check(String str){
        return names.contains(str);
    }
    public static void process(String[] str){
        int index = names.indexOf(str[0]);
        if(index!=-1){
            classes.get(index).run(str);
        }else{
            area.addText("Sorry, I don't know how to do that.", true);
        }
    }
}
