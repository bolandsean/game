package objects;

import javax.swing.*;

public class textArea {
    public JTextArea area;
    public String oldText;
    public textArea(int rows, int columns, boolean editable){
        area = new JTextArea(rows,columns);
        area.setEditable(editable);
    }
    public void setEditable(boolean boo){
        area.setEditable(boo);
    }
    public String getText(){
        return area.getText();
    }
    public void setText(String text){
        area.setText(text);
    }
    public void addText(String text, boolean console){
        oldText = area.getText();
        if(console){
            area.setText(oldText+text+"\n");
        }else{
            area.setText(oldText+">"+text+"\n");
        }
    }
    public void addText(String text){
        oldText = area.getText();
        area.setText(oldText+text+"\n");
    }
}
