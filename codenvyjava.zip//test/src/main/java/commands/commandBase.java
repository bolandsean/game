package commands;

public interface commandBase {
    void run(String[] command);
}
